import { useEffect, useRef, useState } from "react";
import { PDFDocument } from "pdf-lib";

type PdfItem = {
  id: string;
  file: File;
};

const formatBytes = (bytes: number) => {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
};

const isPdf = (file: File) =>
  file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf");

const cleanPdfName = (name: string) => {
  const cleaned = name.trim().replace(/\.pdf$/i, "").replace(/[\\/:*?"<>|]/g, "-");
  return `${cleaned || "KsMarge-merged"}.pdf`;
};

export default function App() {
  const inputRef = useRef<HTMLInputElement>(null);
  const [items, setItems] = useState<PdfItem[]>([]);
  const [dragging, setDragging] = useState(false);
  const [dragIndex, setDragIndex] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [outputName, setOutputName] = useState("KsMarge-merged");
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [mergedSize, setMergedSize] = useState(0);
  const [mergedPages, setMergedPages] = useState(0);

  useEffect(() => {
    return () => {
      if (previewUrl) URL.revokeObjectURL(previewUrl);
    };
  }, [previewUrl]);

  function clearPreview() {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
    setMergedSize(0);
    setMergedPages(0);
  }

  function addFiles(fileList: FileList | File[]) {
    const incoming = Array.from(fileList);
    const valid = incoming.filter(isPdf);
    const rejected = incoming.length - valid.length;

    if (valid.length) {
      clearPreview();
      setItems((current) => [
        ...current,
        ...valid.map((file) => ({
          id: `${file.name}-${file.size}-${file.lastModified}-${crypto.randomUUID()}`,
          file,
        })),
      ]);
      setError("");
      setMessage(`${valid.length} PDF file${valid.length === 1 ? "" : "s"} added.`);
    }
    if (rejected) {
      setError(`${rejected} file${rejected === 1 ? " was" : "s were"} skipped. Please choose PDF files only.`);
    }
  }

  function onInputChange(event: React.ChangeEvent<HTMLInputElement>) {
    if (event.target.files) addFiles(event.target.files);
    event.target.value = "";
  }

  function onDrop(event: React.DragEvent<HTMLElement>) {
    event.preventDefault();
    setDragging(false);
    if (event.dataTransfer.files.length) addFiles(event.dataTransfer.files);
  }

  function moveItem(from: number, to: number) {
    if (from === to || to < 0 || to >= items.length) return;
    clearPreview();
    setItems((current) => {
      const next = [...current];
      const [moved] = next.splice(from, 1);
      next.splice(to, 0, moved);
      return next;
    });
    setMessage("");
  }

  function removeItem(id: string) {
    clearPreview();
    setItems((current) => current.filter((item) => item.id !== id));
    setMessage("");
    setError("");
  }

  async function mergePdfs() {
    if (items.length < 2 || busy) return;
    clearPreview();
    setBusy(true);
    setError("");
    setMessage("Merging your PDFs…");

    try {
      const merged = await PDFDocument.create();

      for (const item of items) {
        const bytes = await item.file.arrayBuffer();
        const source = await PDFDocument.load(bytes);
        const pages = await merged.copyPages(source, source.getPageIndices());
        pages.forEach((page) => merged.addPage(page));
      }

      const output = await merged.save({ useObjectStreams: true });
      const blob = new Blob([output as BlobPart], { type: "application/pdf" });
      const url = URL.createObjectURL(blob);
      setPreviewUrl(url);
      setMergedSize(blob.size);
      setMergedPages(merged.getPageCount());
      setMessage("Your merged PDF is ready. Review it below, then download.");
    } catch (err) {
      console.error(err);
      setError(
        "Could not merge these files. One may be password-protected, damaged, or use unsupported PDF features. Try opening and re-saving it as a standard PDF, then add it again."
      );
      setMessage("");
    } finally {
      setBusy(false);
    }
  }

  function downloadMergedPdf() {
    if (!previewUrl) return;
    const link = document.createElement("a");
    link.href = previewUrl;
    link.download = cleanPdfName(outputName);
    document.body.appendChild(link);
    link.click();
    link.remove();
    setMessage("Your PDF download has started.");
  }

  const totalSize = items.reduce((sum, item) => sum + item.file.size, 0);

  return (
    <main className="page">
      <header className="topbar">
        <a className="brand" href="/" aria-label="KsMarge home">
          <span className="brand-mark">KS</span>
          <span>KsMarge</span>
        </a>
        <span className="privacy"><span className="privacy-dot" /> Files stay on your device</span>
      </header>

      <section className="workspace">
        <div className="intro">
          <div className="eyebrow">FREE · PRIVATE · SIMPLE</div>
          <h1>Merge PDF files</h1>
          <p>Combine multiple PDFs into one file. Arrange them in the order you want.</p>
        </div>

        <section
          className={`dropzone ${dragging ? "dropzone-active" : ""}`}
          onDragOver={(event) => { event.preventDefault(); setDragging(true); }}
          onDragLeave={(event) => {
            if (!event.currentTarget.contains(event.relatedTarget as Node)) setDragging(false);
          }}
          onDrop={onDrop}
        >
          <div className="upload-icon" aria-hidden="true">
            <svg viewBox="0 0 24 24"><path d="M12 16V4m0 0L7.5 8.5M12 4l4.5 4.5M4 15.5v3A1.5 1.5 0 0 0 5.5 20h13a1.5 1.5 0 0 0 1.5-1.5v-3" /></svg>
          </div>
          <h2>Drop your PDF files here</h2>
          <p>or choose files from your device</p>
          <button className="button button-primary" onClick={() => inputRef.current?.click()}>
            Choose PDF files
          </button>
          <input
            ref={inputRef}
            className="visually-hidden"
            type="file"
            accept="application/pdf,.pdf"
            multiple
            onChange={onInputChange}
          />
          <span className="drop-hint">PDF files only · No upload · No account</span>
        </section>

        {items.length > 0 && (
          <section className="file-section">
            <div className="list-heading">
              <div>
                <h2>Your files <span className="count">{items.length}</span></h2>
                <p>Drag a file to change its position.</p>
              </div>
              <button className="text-button" onClick={() => {
                clearPreview();
                setItems([]);
                setMessage("");
                setError("");
              }}>
                Clear all
              </button>
            </div>

            <div className="file-list">
              {items.map((item, index) => (
                <div
                  className={`file-row ${dragIndex === index ? "file-row-dragging" : ""}`}
                  key={item.id}
                  draggable
                  onDragStart={(event) => {
                    setDragIndex(index);
                    event.dataTransfer.effectAllowed = "move";
                    event.dataTransfer.setData("text/plain", String(index));
                  }}
                  onDragOver={(event) => event.preventDefault()}
                  onDrop={(event) => {
                    event.preventDefault();
                    const from = Number(event.dataTransfer.getData("text/plain"));
                    if (Number.isInteger(from)) moveItem(from, index);
                    setDragIndex(null);
                  }}
                  onDragEnd={() => setDragIndex(null)}
                >
                  <span className="grip" aria-label="Drag to reorder">
                    <svg viewBox="0 0 16 16"><circle cx="5" cy="4" r="1"/><circle cx="11" cy="4" r="1"/><circle cx="5" cy="8" r="1"/><circle cx="11" cy="8" r="1"/><circle cx="5" cy="12" r="1"/><circle cx="11" cy="12" r="1"/></svg>
                  </span>
                  <span className="pdf-icon" aria-hidden="true">
                    <svg viewBox="0 0 24 24"><path d="M6 2.75h8l4 4v14.5H6z"/><path d="M14 2.75v4h4M8.5 15.5h7M8.5 18h5"/></svg>
                  </span>
                  <div className="file-info">
                    <span className="file-name" title={item.file.name}>{item.file.name}</span>
                    <span className="file-size">{formatBytes(item.file.size)}</span>
                  </div>
                  <span className="file-order">{index + 1}</span>
                  <button className="remove-button" onClick={() => removeItem(item.id)} aria-label={`Remove ${item.file.name}`} title="Remove file">
                    <svg viewBox="0 0 20 20"><path d="M4 6h12M8 6V4h4v2m-6 0 .7 10h6.6L14 6M8.5 9v4m3-4v4"/></svg>
                  </button>
                </div>
              ))}
            </div>

            <div className="list-footer">
              <span>{items.length} files · {formatBytes(totalSize)} total</span>
              <button className="text-button" onClick={() => inputRef.current?.click()}>+ Add more</button>
            </div>

            <div className="output-name">
              <label htmlFor="output-name">Output file name</label>
              <div className="name-input-wrap">
                <input
                  id="output-name"
                  value={outputName}
                  onChange={(event) => setOutputName(event.target.value)}
                  maxLength={80}
                  placeholder="KsMarge-merged"
                />
                <span>.pdf</span>
              </div>
            </div>

            <button className="button button-merge" disabled={items.length < 2 || busy} onClick={mergePdfs}>
              {busy ? <><span className="spinner" /> Merging…</> : "Merge PDFs"}
            </button>
            {items.length < 2 && <p className="button-note">Add at least 2 PDF files to merge.</p>}
          </section>
        )}

        {message && <div className="status-message" role="status">{message}</div>}
        {error && <div className="error-message" role="alert">{error}</div>}

        {previewUrl && (
          <section className="preview-section">
            <div className="preview-heading">
              <div>
                <h2>Preview merged PDF</h2>
                <p>{mergedPages} pages · {formatBytes(mergedSize)}</p>
              </div>
              <span className="ready-label">Ready</span>
            </div>
            <div className="preview-frame">
              <iframe src={previewUrl} title="Preview of merged PDF" />
            </div>
            <button className="button button-download" onClick={downloadMergedPdf}>
              Download {cleanPdfName(outputName)}
            </button>
            <p className="preview-note">Check the page order above before downloading.</p>
          </section>
        )}

        <div className="trust-note">
          <svg viewBox="0 0 20 20"><path d="M10 2.5 16 5v4.2c0 3.8-2.5 6.5-6 8.3-3.5-1.8-6-4.5-6-8.3V5z"/><path d="m7.2 9.8 1.8 1.8 3.8-4"/></svg>
          <span><strong>Your files never leave your device.</strong> Everything is processed locally in your browser.</span>
        </div>
      </section>

      <footer>KsMarge <span>·</span> A simple tool that respects your privacy.</footer>
    </main>
  );
}
